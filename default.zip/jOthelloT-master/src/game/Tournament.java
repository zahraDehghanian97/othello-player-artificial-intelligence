package game;

public class Tournament {
    public static int GAME = 2;
}
